"use client"

import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Eye, MessageSquare, Clock, Star } from "lucide-react"
import type { DocumentWithRelations } from "@/lib/types"

interface DocumentCardProps {
  document: DocumentWithRelations
  priority?: boolean
}

export function DocumentCard({ document, priority = false }: DocumentCardProps) {
  const categoryColor = document.category?.color || "#6366f1"

  return (
    <Link href={`/document/${document.id}`} className="group block">
      <Card className="overflow-hidden border-0 bg-card/50 hover:bg-card transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-1">
        <div className="relative aspect-[16/10] overflow-hidden">
          {document.cover_url ? (
            <Image
              src={document.cover_url}
              alt={document.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              priority={priority}
            />
          ) : (
            <div 
              className="w-full h-full flex items-center justify-center"
              style={{ backgroundColor: `${categoryColor}20` }}
            >
              <span 
                className="text-4xl font-serif font-bold opacity-30"
                style={{ color: categoryColor }}
              >
                {document.title.charAt(0)}
              </span>
            </div>
          )}
          
          {/* Featured badge */}
          {document.is_featured && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-amber-500/90 text-amber-950 hover:bg-amber-500">
                <Star className="w-3 h-3 mr-1 fill-current" />
                Destacado
              </Badge>
            </div>
          )}

          {/* Category badge */}
          {document.category && (
            <div className="absolute bottom-2 left-2">
              <Badge
                style={{ 
                  backgroundColor: `${categoryColor}e6`,
                  color: '#fff'
                }}
                className="font-medium"
              >
                {document.category.name}
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-4">
          <h3 className="font-semibold text-base leading-tight mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {document.title}
          </h3>
          
          {document.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {document.description}
            </p>
          )}

          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Eye className="w-3.5 h-3.5" />
              {formatNumber(document.views_count)}
            </span>
            <span className="flex items-center gap-1">
              <MessageSquare className="w-3.5 h-3.5" />
              {document.comments_count}
            </span>
            {document.estimated_read_time && (
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {document.estimated_read_time} min
              </span>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M"
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K"
  }
  return num.toString()
}
