"use client"

import Link from "next/link"
import { useAuth } from "@/components/providers/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ThemeToggle } from "./theme-toggle"
import { SearchCommand } from "./search-command"
import { NotificationBell } from "./notification-bell"
import { 
  Search, 
  Menu, 
  Library, 
  User, 
  Settings, 
  LogOut, 
  Shield,
  BookMarked,
  History
} from "lucide-react"
import { useState } from "react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Header() {
  const { user, profile, isAdmin, signOut, isLoading } = useAuth()
  const [searchOpen, setSearchOpen] = useState(false)

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center gap-4 px-4 md:px-6">
          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72">
              <nav className="flex flex-col gap-4 mt-8">
                <Link href="/" className="flex items-center gap-2 text-lg font-semibold">
                  <Library className="h-6 w-6" />
                  Biblioteca
                </Link>
                <Link href="/categories" className="text-muted-foreground hover:text-foreground transition-colors">
                  Categorías
                </Link>
                <Link href="/series" className="text-muted-foreground hover:text-foreground transition-colors">
                  Series
                </Link>
                {user && (
                  <>
                    <Link href="/favorites" className="text-muted-foreground hover:text-foreground transition-colors">
                      Favoritos
                    </Link>
                    <Link href="/history" className="text-muted-foreground hover:text-foreground transition-colors">
                      Historial
                    </Link>
                  </>
                )}
                {isAdmin && (
                  <Link href="/admin" className="text-muted-foreground hover:text-foreground transition-colors">
                    Panel Admin
                  </Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>

          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <Library className="h-6 w-6" />
            <span className="hidden sm:inline-block">Biblioteca</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 ml-6">
            <Link href="/categories" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Categorías
            </Link>
            <Link href="/series" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Series
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="flex-1 max-w-xl mx-4">
            <Button
              variant="outline"
              className="w-full justify-start text-muted-foreground h-9 px-3"
              onClick={() => setSearchOpen(true)}
            >
              <Search className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Buscar documentos...</span>
              <span className="sm:hidden">Buscar...</span>
              <kbd className="pointer-events-none ml-auto hidden h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground sm:flex">
                <span className="text-xs">⌘</span>K
              </kbd>
            </Button>
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-2">
            <ThemeToggle />
            
            {!isLoading && (
              <>
                {user ? (
                  <>
                    <NotificationBell />
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={profile?.avatar_url || ""} alt={profile?.display_name || ""} />
                            <AvatarFallback>
                              {profile?.display_name?.charAt(0)?.toUpperCase() || user.email?.charAt(0)?.toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-56">
                        <div className="flex items-center justify-start gap-2 p-2">
                          <div className="flex flex-col space-y-1 leading-none">
                            <p className="font-medium">{profile?.display_name || "Usuario"}</p>
                            <p className="text-xs text-muted-foreground">{user.email}</p>
                          </div>
                        </div>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href="/favorites" className="cursor-pointer">
                            <BookMarked className="mr-2 h-4 w-4" />
                            Favoritos
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href="/history" className="cursor-pointer">
                            <History className="mr-2 h-4 w-4" />
                            Historial
                          </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild>
                          <Link href="/profile" className="cursor-pointer">
                            <User className="mr-2 h-4 w-4" />
                            Perfil
                          </Link>
                        </DropdownMenuItem>
                        {isAdmin && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem asChild>
                              <Link href="/admin" className="cursor-pointer">
                                <Shield className="mr-2 h-4 w-4" />
                                Panel Admin
                              </Link>
                            </DropdownMenuItem>
                          </>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={signOut} className="cursor-pointer text-destructive">
                          <LogOut className="mr-2 h-4 w-4" />
                          Cerrar sesión
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </>
                ) : (
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" asChild>
                      <Link href="/auth/login">Iniciar sesión</Link>
                    </Button>
                    <Button size="sm" asChild>
                      <Link href="/auth/sign-up">Registrarse</Link>
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </header>

      <SearchCommand open={searchOpen} onOpenChange={setSearchOpen} />
    </>
  )
}
