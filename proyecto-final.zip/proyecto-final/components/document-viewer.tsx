"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/components/providers/auth-provider"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { 
  ArrowLeft, 
  Heart, 
  Share2, 
  BookmarkPlus, 
  Check,
  Eye,
  MessageSquare,
  Clock,
  X
} from "lucide-react"
import { ThemeToggle } from "./theme-toggle"
import type { DocumentWithRelations } from "@/lib/types"
import { toast } from "sonner"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"

interface DocumentViewerProps {
  document: DocumentWithRelations
  seriesDocuments?: DocumentWithRelations[]
  children?: React.ReactNode
}

export function DocumentViewer({ document, seriesDocuments = [], children }: DocumentViewerProps) {
  const router = useRouter()
  const { user } = useAuth()
  const [progress, setProgress] = useState(0)
  const [isFavorite, setIsFavorite] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [htmlContent, setHtmlContent] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const contentRef = useRef<HTMLDivElement>(null)
  const supabase = createClient()

  // Check if document is favorite
  useEffect(() => {
    if (!user) return

    const checkFavorite = async () => {
      const { data } = await supabase
        .from("favorites")
        .select("id")
        .eq("user_id", user.id)
        .eq("document_id", document.id)
        .single()

      setIsFavorite(!!data)
    }

    checkFavorite()
  }, [user, document.id, supabase])

  // Load HTML content
  useEffect(() => {
    const loadContent = async () => {
      if (!document.content_url) {
        setIsLoading(false)
        return
      }

      try {
        const response = await fetch(document.content_url)
        const html = await response.text()
        setHtmlContent(html)
      } catch {
        toast.error("Error al cargar el documento")
      } finally {
        setIsLoading(false)
      }
    }

    loadContent()
  }, [document.content_url])

  // Track reading progress
  useEffect(() => {
    const handleScroll = () => {
      if (!contentRef.current) return

      const element = contentRef.current
      const scrollTop = window.scrollY
      const docHeight = element.scrollHeight - window.innerHeight
      const scrollPercent = Math.min(Math.round((scrollTop / docHeight) * 100), 100)
      
      setProgress(isNaN(scrollPercent) ? 0 : scrollPercent)

      // Auto-minimize header on scroll
      setIsMinimized(scrollTop > 300)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Save reading progress
  useEffect(() => {
    if (!user || progress === 0) return

    const saveProgress = async () => {
      await supabase
        .from("reading_history")
        .upsert({
          user_id: user.id,
          document_id: document.id,
          progress,
          last_read_at: new Date().toISOString(),
        }, {
          onConflict: "user_id,document_id",
        })
    }

    const debounce = setTimeout(saveProgress, 1000)
    return () => clearTimeout(debounce)
  }, [user, document.id, progress, supabase])

  const toggleFavorite = async () => {
    if (!user) {
      toast.error("Inicia sesión para guardar favoritos")
      return
    }

    if (isFavorite) {
      await supabase
        .from("favorites")
        .delete()
        .eq("user_id", user.id)
        .eq("document_id", document.id)
      
      setIsFavorite(false)
      toast.success("Eliminado de favoritos")
    } else {
      await supabase
        .from("favorites")
        .insert({
          user_id: user.id,
          document_id: document.id,
        })
      
      setIsFavorite(true)
      toast.success("Añadido a favoritos")
    }
  }

  const handleShare = async () => {
    const url = window.location.href
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: document.title,
          text: document.description || undefined,
          url,
        })
      } catch {
        // User cancelled share
      }
    } else {
      await navigator.clipboard.writeText(url)
      toast.success("Enlace copiado al portapapeles")
    }
  }

  return (
    <div className="min-h-screen bg-background" ref={contentRef}>
      {/* Reading Progress Bar */}
      <div 
        className="reading-progress"
        style={{ width: `${progress}%` }}
      />

      {/* Header */}
      <header 
        className={`sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b transition-all duration-300 ${
          isMinimized ? "py-2" : "py-4"
        }`}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 min-w-0">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => router.back()}
              >
                <ArrowLeft className="h-5 w-5" />
                <span className="sr-only">Volver</span>
              </Button>

              {isMinimized && (
                <h1 className="font-semibold truncate">
                  {document.title}
                </h1>
              )}
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground hidden sm:block">
                {progress}% leído
              </span>
              <ThemeToggle />
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleFavorite}
              >
                {isFavorite ? (
                  <Check className="h-5 w-5 text-primary" />
                ) : (
                  <BookmarkPlus className="h-5 w-5" />
                )}
                <span className="sr-only">Guardar</span>
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleShare}
              >
                <Share2 className="h-5 w-5" />
                <span className="sr-only">Compartir</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Document Header */}
      <div className="border-b">
        <div className="container mx-auto px-4 py-12 md:py-16">
          <div className="max-w-3xl mx-auto">
            {document.category && (
              <Badge
                className="mb-4"
                style={{ 
                  backgroundColor: `${document.category.color}e6`,
                  color: '#fff'
                }}
              >
                {document.category.name}
              </Badge>
            )}

            <h1 className="text-3xl md:text-5xl font-bold font-serif mb-4 text-balance">
              {document.title}
            </h1>

            {document.description && (
              <p className="text-lg md:text-xl text-muted-foreground mb-6 text-pretty">
                {document.description}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Eye className="w-4 h-4" />
                {document.views_count} vistas
              </span>
              <span className="flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4" />
                {document.comments_count} comentarios
              </span>
              {document.estimated_read_time && (
                <span className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4" />
                  {document.estimated_read_time} min de lectura
                </span>
              )}
              {document.published_at && (
                <span>
                  Publicado {formatDistanceToNow(new Date(document.published_at), {
                    addSuffix: true,
                    locale: es,
                  })}
                </span>
              )}
            </div>

            {document.tags && document.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-4">
                {document.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Document Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-24">
              <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent" />
            </div>
          ) : htmlContent ? (
            <div 
              className="document-viewer prose prose-lg dark:prose-invert max-w-none"
              dangerouslySetInnerHTML={{ __html: htmlContent }}
            />
          ) : (
            <div className="text-center py-24">
              <p className="text-muted-foreground">
                El contenido de este documento no está disponible
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Children (Series Nav, Comments, etc.) */}
      <div className="container mx-auto px-4 pb-12">
        <div className="max-w-3xl mx-auto">
          {children}
        </div>
      </div>
    </div>
  )
}
