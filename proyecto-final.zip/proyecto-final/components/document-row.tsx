"use client"

import { useRef } from "react"
import { DocumentCard } from "./document-card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { DocumentWithRelations } from "@/lib/types"
import Link from "next/link"

interface DocumentRowProps {
  title: string
  documents: DocumentWithRelations[]
  href?: string
  color?: string
}

export function DocumentRow({ title, documents, href, color }: DocumentRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (!scrollRef.current) return
    const scrollAmount = 320
    scrollRef.current.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth",
    })
  }

  if (documents.length === 0) return null

  return (
    <section className="py-6">
      <div className="flex items-center justify-between mb-4 px-4 md:px-6">
        <div className="flex items-center gap-3">
          {color && (
            <div 
              className="w-1 h-6 rounded-full" 
              style={{ backgroundColor: color }}
            />
          )}
          <h2 className="text-xl font-semibold">{title}</h2>
        </div>
        <div className="flex items-center gap-2">
          {href && (
            <Link 
              href={href} 
              className="text-sm text-muted-foreground hover:text-foreground transition-colors mr-2"
            >
              Ver todo
            </Link>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hidden md:flex"
            onClick={() => scroll("left")}
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Anterior</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hidden md:flex"
            onClick={() => scroll("right")}
          >
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Siguiente</span>
          </Button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-6 pb-2 snap-x snap-mandatory"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {documents.map((doc, index) => (
          <div
            key={doc.id}
            className="flex-shrink-0 w-[280px] md:w-[300px] snap-start animate-fade-in-up"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <DocumentCard document={doc} priority={index < 4} />
          </div>
        ))}
      </div>
    </section>
  )
}
